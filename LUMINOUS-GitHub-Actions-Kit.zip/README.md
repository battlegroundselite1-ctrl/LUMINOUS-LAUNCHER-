# LUMINOUS — GitHub Actions APK build kit

## What this does
GitHub Actions builds the Android starter project and uploads a debug APK as a workflow artifact. This starter currently imports and reads a JSON profile; it does **not** yet include the engine needed to launch Minecraft.

## Setup from an Android phone
1. In GitHub, create a new repository named `LUMINOUS-Launcher` (Public or Private).
2. Upload `LUMINOUS-Launcher-Android-Starter.zip` to the repository root. Use the starter ZIP you downloaded separately from ChatGPT.
3. In the repository, use **Add file → Create new file** and name it exactly:
   `.github/workflows/build-apk.yml`
4. Copy the contents of the `build-apk.yml` file from this kit into the editor and commit the file.
5. Open the repository's **Actions** tab. Choose **Build LUMINOUS APK** and tap **Run workflow** (or wait for the push-triggered build).
6. When the run finishes with a green check, open the run, scroll to **Artifacts**, and download `LUMINOUS-debug-APK`.
7. Extract the downloaded artifact ZIP on your phone; inside is `app-debug.apk`. Tap it to install. Android may ask you to allow installs from your browser/file manager.

## Important
- GitHub Actions builds a debug APK; it is for testing, not a production-signed release.
- Keep your GitHub account secure and never publish passwords, Microsoft tokens, or other secrets.
- The APK is a starter app. Minecraft launch is not functional until a compatible Android runtime, game installation/download logic, authentication, mod-loader integration, and rendering/input support are added.
