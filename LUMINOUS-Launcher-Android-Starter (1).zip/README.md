# LUMINOUS Launcher — Android starter

This is an Android Studio starter project for a branded Minecraft profile launcher.

## Included
- Dark LUMINOUS interface
- Import a `.json` profile using Android's document picker
- Parse `name`, `versionId`, and infer likely Minecraft version/mod loader
- Display a suggested Java version for common Minecraft generations

## Important limitation
This project is **not yet a Minecraft launcher** and does not build an installable APK by itself. The launch button intentionally explains that the runtime is not integrated. To actually run Minecraft Java Edition on Android, the project still needs a compatible Java runtime, game/library/asset downloading, Microsoft authentication, mod-loader installation, version-specific launch arguments, and an Android-compatible renderer/input layer. A profile JSON alone cannot launch the game.

For a real implementation, evaluate integrating or forking a suitable open-source Android Minecraft Java launcher/runtime, and comply with its license and Minecraft/Microsoft authentication requirements. Do not bundle account credentials or distribute copyrighted game files.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the output APK location.

Requires Android Studio with a compatible JDK/Gradle setup and Android SDK platform 35.
