package com.luminous.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var profileText: TextView
    private lateinit var statusText: TextView
    private var importedProfile: JSONObject? = null

    private val bg = Color.rgb(10, 13, 27)
    private val panel = Color.rgb(22, 28, 50)
    private val accent = Color.rgb(139, 92, 246)
    private val muted = Color.rgb(183, 191, 215)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "✦  L U M I N O U S"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MINECRAFT JAVA • ANDROID LAUNCHER"
            textSize = 11f
            letterSpacing = .12f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(26))
        }
        root.addView(subtitle, matchWrap())

        root.addView(label("GAME PROFILE"))
        profileText = TextView(this).apply {
            text = "No configuration imported yet.\\nImport your launcher JSON to inspect its version and mod loader."
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        root.addView(profileText, matchWrap())

        val importButton = Button(this).apply {
            text = "IMPORT JSON CONFIG"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, 101)
            }
        }
        root.addView(importButton, buttonParams())

        val launchButton = Button(this).apply {
            text = "LAUNCH MINECRAFT"
            setOnClickListener {
                statusText.text =
                    "Runtime not connected yet. This prototype can read your profile, but it cannot launch Minecraft until a compatible Android Java runtime, game-file installer, authentication flow, and renderer are integrated."
            }
        }
        root.addView(launchButton, buttonParams())

        statusText = TextView(this).apply {
            text = "Ready. Import a JSON profile to begin."
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(12), 0, dp(18))
        }
        root.addView(statusText, matchWrap())

        root.addView(label("CURRENT BUILD"))
        val note = TextView(this).apply {
            text = "LUMINOUS 0.1.0\\nProfile reader prototype • Android 8+\\n\\nThis is a starter project, not a working Minecraft runtime yet."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        root.addView(note, matchWrap())
    }

    @Deprecated("Uses activity result API for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 101 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Could not read file")
            val obj = JSONObject(json)
            importedProfile = obj
            val name = obj.optString("name", "Unknown")
            val versionId = obj.optString("versionId", "")
            val version = when {
                versionId.contains("1.8.9") -> "1.8.9"
                else -> versionId.substringBefore("-").ifBlank { "Unknown" }
            }
            val loader = when {
                versionId.contains("forge", ignoreCase = true) ||
                    name.contains("forge", ignoreCase = true) -> "Forge"
                versionId.contains("fabric", ignoreCase = true) ||
                    name.contains("fabric", ignoreCase = true) -> "Fabric"
                else -> "Unknown / vanilla"
            }
            val java = when {
                version.startsWith("1.8") || version.startsWith("1.12") -> "Java 8 (recommended)"
                version.startsWith("1.18") || version.startsWith("1.19") ||
                    version.startsWith("1.20") -> "Java 17 (most versions)"
                version.startsWith("1.21") -> "Java 21 (most versions)"
                else -> "Select based on exact Minecraft version"
            }
            profileText.text = "Name: $name\\nMinecraft: $version\\nLoader: $loader\\nVersion ID: $versionId\\nJava: $java"
            statusText.text = "Configuration imported successfully. Minecraft launch support is not yet integrated."
        } catch (e: Exception) {
            statusText.text = "Could not read this JSON: ${e.message ?: "invalid file"}"
        }
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 12f
        letterSpacing = .12f
        setTextColor(muted)
        setPadding(0, dp(12), 0, dp(8))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(10) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
